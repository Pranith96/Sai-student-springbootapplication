
public class Example2 {

	public void addition(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	public static String bird(String name) {
		Example3 ex = new Example3();
		ex.bike();
		return name;
	}
}
