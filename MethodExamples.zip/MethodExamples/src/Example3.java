
public class Example3 {

	public void bike() {
		System.out.println("bike");
	}
}
