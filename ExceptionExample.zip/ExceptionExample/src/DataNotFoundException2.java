
// runtime
public class DataNotFoundException2 extends RuntimeException {

	public DataNotFoundException2(String message) {
		super(message);
	}
}
