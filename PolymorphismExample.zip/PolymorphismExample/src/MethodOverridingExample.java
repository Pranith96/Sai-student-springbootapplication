
public class MethodOverridingExample {

	public void add(int a, int b) {
		int c = a + b;
		System.out.println(c);
	}
}
