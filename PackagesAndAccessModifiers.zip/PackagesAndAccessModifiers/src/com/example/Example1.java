package com.example;

public class Example1 {

	public void hi() {
		System.out.println("hi");
		hello();
	}

	private void hello() {
		System.out.println("hello");
	}

	protected void welcome() {
		System.out.println("welcome");
	}

	void print() {
		System.out.println("print");
	}
}
