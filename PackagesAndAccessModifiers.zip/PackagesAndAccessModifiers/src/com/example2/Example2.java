package com.example2;

public class Example2 {

	public void hi1() {
		System.out.println("hi1111");
	}

	private void hello1() {
		System.out.println("hello1111");
	}

	protected void welcome1() {
		System.out.println("welcome11111");
	}

	void print1() {
		System.out.println("print1111");
	}
}
