This is spring boot projects includes all basics functionality and will added further more to same project

- How to use H2 in-memory database
- How to write JPQL,Native,Named queries
- How to config Actuators
