package io.springboot.h2database.springbooth2databse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbooth2databseApplicationTests {

	@Test
	void contextLoads() {
	}

}
