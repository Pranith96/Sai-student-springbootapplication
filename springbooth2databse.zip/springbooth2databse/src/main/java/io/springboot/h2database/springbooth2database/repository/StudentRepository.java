package io.springboot.h2database.springbooth2database.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.springboot.h2database.springbooth2database.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {

	@Query("select s from Student s where s.name = ?1")
	Optional<Student> findByName(String name);

	@Query("select s from Student s where s.id = ?1 and s.name=?2")
	Optional<Student> findByIdAndName(Integer id, String name);

	@Query("select s from Student s where s.course = :course")
	Optional<Student> findByCourse(String course);

	@Query(value = "select * from Student s where s.college = :college", nativeQuery = true)
	Optional<Student> findByCollege(@Param("college") String college);

}
