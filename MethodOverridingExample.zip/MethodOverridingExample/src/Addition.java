
public class Addition {

	public void add(int a, int b) {
		System.out.println(a+b);
	}
	
	public void hi() {
		System.out.println("HI");
	}
}
