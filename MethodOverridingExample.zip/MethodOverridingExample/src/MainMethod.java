
public class MainMethod {

	public static void main(String[] args) {
		Summation sm = new Summation(); //compile time
		sm.add(10, 5);
		sm.hi();
		
		//runtime polymorphism
		Addition sm1 = new Summation(); //runtime 
		sm1.add(15, 5);
		sm1.hi();
		
	}
}
