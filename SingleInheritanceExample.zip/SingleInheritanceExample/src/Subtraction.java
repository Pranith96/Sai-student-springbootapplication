
public class Subtraction extends Addition {

	public void sub(int a, int b) {
		int c = a - b;
		System.out.println(c);
	}

	public String welcome(String message) {
		return message;
	}
}
