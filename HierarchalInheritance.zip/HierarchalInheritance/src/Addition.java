
public class Addition extends Calculator {

	public void add(int a, int b) {
		System.out.println(a + b);
	}

	public void mul(int a, int b, int c) {
		int d = a * b * c;
		System.out.println(d);
	}
}
