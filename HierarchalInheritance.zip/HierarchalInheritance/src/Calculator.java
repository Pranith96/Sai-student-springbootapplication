
public class Calculator {

	public void message(String data) {
		String value = data + "welcome";
		System.out.println(value);
	}
}
