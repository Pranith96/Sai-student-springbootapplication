
public class Subtraction extends Calculator {

	public void sub(int a, int b) {
		int c = a - b;
		System.out.println(c);
	}

	public String welcome(String message) {
		return message;
	}
}
